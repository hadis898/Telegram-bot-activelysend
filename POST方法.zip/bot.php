<?php
$logs = [];

// 获取日志
if ($_GET) {
    echo json_encode($logs);
}

// 发送消息和记录日志
if ($_POST) {
    $token = $_POST['token'];
    $chat_id = $_POST['chat_id'];
    $text = $_POST['text'];
    
    $url = "https://api.telegram.org/bot$token/sendMessage";
    $params = ['chat_id' => $chat_id, 'text' => $text];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $now = date('Y-m-d H:i:s');
    $logs[] = "[$now] sendMessage - $response";
}



// 输出日志数组
echo json_encode($logs); 


?>

